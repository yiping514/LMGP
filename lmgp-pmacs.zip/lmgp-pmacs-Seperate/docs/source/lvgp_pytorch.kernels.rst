Kernels
=======

Kernels are imported from gpytorch. Refer to the gpytorch documentation at https://docs.gpytorch.ai/en/v1.5.1/kernels.html