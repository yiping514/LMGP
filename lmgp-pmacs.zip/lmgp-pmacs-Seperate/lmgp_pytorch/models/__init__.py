from .gpregression import GPR
from .lvgp import LVGPR
from .lmgp import LMGP