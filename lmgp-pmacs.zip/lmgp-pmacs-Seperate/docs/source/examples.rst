==========
User Guide
==========

.. toctree::
   :maxdepth: 1

   notebooks/Demo_borehole1D.ipynb
   notebooks/spinels_model.ipynb
   notebooks/Demo_singleprecision.ipynb